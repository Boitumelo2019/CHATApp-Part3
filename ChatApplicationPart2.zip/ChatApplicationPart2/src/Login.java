/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_Lab
 */
public class Login {
    public boolean authenticate(User user, String username, String password) {
        return user.getUsername().equals(username) && user.getPassword().equals(password);
    }

    public String getLoginStatus(User user, boolean isLoginSuccessful) {
        if (isLoginSuccessful) {
            return "Welcome " + user.getFirstName() + ", " + user.getLastName() + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}