/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_Lab
 */
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class MessageGUI extends JFrame {

    private User user;
    private List<Message> userMessages = new ArrayList<>();
    private int numToSend = 0;
    private int messagesSent = 0;

    public MessageGUI(User user) {
        this.user = user;
        initComponents();
    }

    private void initComponents() {
        setTitle("QuickChat - Messaging");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JOptionPane.showMessageDialog(this, "Welcome to QuickChat.");

        // Ask user how many messages to send
        boolean validNum = false;
        while (!validNum) {
            String numStr = JOptionPane.showInputDialog(this, "How many messages would you like to send?");
            try {
                numToSend = Integer.parseInt(numStr);
                validNum = numToSend > 0;
            } catch (Exception e) {
                validNum = false;
            }
        }

        showMenu();
    }

    private void showMenu() {
        while(true) {
            String[] options = {"Send Message", "Show Recently Sent Messages", "Quit"};
            int choice = JOptionPane.showOptionDialog(this, "Choose an option:",
                    "QuickChat Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);

            if (choice == 0) { // Send Message
                if (messagesSent >= numToSend) {
                    JOptionPane.showMessageDialog(this, "Message limit reached.");
                    continue;
                }
                sendMessage();
            } else if (choice == 1) { // Show Recently Sent Messages
                if (userMessages.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Coming Soon.");
                } else {
                    JOptionPane.showMessageDialog(this, Message.printMessages());
                }
            } else if (choice == 2) { // Quit
                JOptionPane.showMessageDialog(this, "Total messages sent: " + Message.returnTotalMessages());
                System.exit(0);
            }
        }
    }

    private void sendMessage() {
        String recipient = JOptionPane.showInputDialog(this, "Enter recipient cell number (+code...):");
        String messageText = JOptionPane.showInputDialog(this, "Enter message (max 250 chars):");

        if (messageText.length() > 250) {
            JOptionPane.showMessageDialog(this, "Message exceeds 250 characters by " + (messageText.length()-250) + ", please reduce size.");
            return;
        }

        Message msg = new Message(messagesSent + 1, recipient, messageText);

        // Recipient validation
        if (msg.checkRecipientCell() == 0) {
            JOptionPane.showMessageDialog(this, "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
            return;
        } else {
            JOptionPane.showMessageDialog(this, "Cell phone number successfully captured.");
        }

        // Message ID validation
        if (!msg.checkMessageID()) {
            JOptionPane.showMessageDialog(this, "Message ID is not correctly generated.");
            return;
        } else {
            JOptionPane.showMessageDialog(this, "Message ID generated: " + msg.messageID);
        }

        // Show hash
        JOptionPane.showMessageDialog(this, "Message hash: " + msg.messageHash);

        // Send/disregard/store
        String[] sendOptions = {"Send Message", "Disregard Message", "Store Message to send later"};
        int sendChoice = JOptionPane.showOptionDialog(this, "Choose what to do with message:",
                "Send Option", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, sendOptions, sendOptions[0]);
        String result = msg.SentMessage(sendChoice + 1);
        JOptionPane.showMessageDialog(this, result);

        if (sendChoice == 0) { // Send
            // Show message details
            JOptionPane.showMessageDialog(this, "Message Details:\nMessageID: " + msg.messageID +
                    "\nMessage Hash: " + msg.messageHash +
                    "\nRecipient: " + msg.recipient +
                    "\nMessage: " + msg.messageText);
            userMessages.add(msg);
            messagesSent++;
        }
    }
}
    

