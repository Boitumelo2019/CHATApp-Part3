
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {
    public String messageID;
    public int messageNum;
    public String recipient;
    public String messageText;
    public String messageHash;

    // Static list to accumulate messages
    public static List<Message> sentMessages = new ArrayList<>();

    public Message(int messageNum, String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.messageNum = messageNum;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    // Generates a random 10-digit ID
    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < 10; i++) {
            sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }

    // Ensures message ID is not more than 10 chars
    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    // Ensures recipient cell is <= 10 chars and starts with +
    public int checkRecipientCell() {
        if(recipient.length() <= 10 && recipient.startsWith("+")) {
            return 1; // success
        }
        return 0; // fail
    }

    // Creates message hash per assignment spec
    public String createMessageHash() {
        String firstTwo = messageID.substring(0,2);
        String firstWord = "", lastWord = "";
        String[] words = messageText.trim().split("\\s+");
        if(words.length >= 1) firstWord = words[0];
        if(words.length >= 1) lastWord = words[words.length-1];
        return (firstTwo + ":" + messageNum + ":" + firstWord.toUpperCase() + lastWord.toUpperCase());
    }

    // Allows user to choose what to do with message
    public String SentMessage(int choice) {
        switch(choice) {
            case 1: // send
                sentMessages.add(this);
                return "Message successfully sent.";
            case 2: // discard
                return "Press 0 to delete message.";
            case 3: // store for later
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    // Returns details of all sent messages
    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for(Message m : sentMessages) {
            sb.append("MessageID: ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n\n");
        }
        return sb.toString();
    }

    // Returns total messages sent
    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    String checkMessageLength() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }}


