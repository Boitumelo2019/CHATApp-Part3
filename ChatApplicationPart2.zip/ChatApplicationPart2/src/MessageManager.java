/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_Lab
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * MessageManager (Part 3)
 *
 * Manages the arrays required by Part 3:
 * - Sent messages
 * - Disregarded messages
 * - Stored messages
 * - Message hashes
 * - Message IDs
 *
 * Provides operations for:
 * - Populating test data (as per assignment brief)
 * - Displaying sender/recipient details
 * - Finding longest message (across test data)
 * - Searching by message ID
 * - Searching by recipient
 * - Deleting by message hash
 * - Displaying a report of sent messages
 *
 * Integrates with your Part 2 Message and User classes (no changes made to Part 2 files).
 */
public class MessageManager {

    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> disregardedMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();
    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIDs = new ArrayList<>();

    /**
     * Populate the manager with the test data provided in the assignment brief.
     * This creates Message objects and places them into the appropriate arrays
     * (sent, stored, disregarded). Also populates messageHashes and messageIDs lists.
     *
     * Note: To make searching by "message ID" deterministic for the tests,
     * the messageID for specific test messages (e.g., message 4) is explicitly set
     * to match the test data (e.g., "0838884567"). The Message object fields are public
     * in your Part 2 code, so we set them here without modifying Part 2 files.
     */
    public void populateTestData() {
        // Test Data Message 1
        Message m1 = new Message(1, "+27834557896", "Did you get the cake?");
        // Test Data Message 2
        Message m2 = new Message(2, "+27838884567", "Where are you? You are late! I have asked you to be on time.");
        // Test Data Message 3
        Message m3 = new Message(3, "+27834484567", "Yohoooo, I am at your gate.");
        // Test Data Message 4 (Developer number without plus sign)
        Message m4 = new Message(4, "0838884567", "It is dinner time !");
        // Test Data Message 5
        Message m5 = new Message(5, "+27838884567", "Ok, I am leaving without you.");

        // For deterministic tests, set messageID for message 4 (as per brief)
        // and recompute its messageHash to reflect the new ID.
        m4.messageID = "0838884567";
        m4.messageHash = m4.createMessageHash();

        // Add all message IDs and hashes (for all test messages)
        for (Message m : new Message[]{m1, m2, m3, m4, m5}) {
            // Ensure messageHash matches any potential manual ID override
            m.messageHash = m.createMessageHash();
            messageIDs.add(m.messageID);
            messageHashes.add(m.messageHash);
        }

        // Place messages into arrays according to the flags in the brief:
        // Message 1 — Sent
        addMessageToSent(m1);
        // Message 2 — Stored
        addMessageToStored(m2);
        // Message 3 — Disregard
        addMessageToDisregarded(m3);
        // Message 4 — Sent
        addMessageToSent(m4);
        // Message 5 — Stored
        addMessageToStored(m5);
    }

    private void addMessageToSent(Message m) {
        // Use Message.SentMessage to keep parity with existing behaviour if needed.
        m.SentMessage(1); // this will also add to Message.sentMessages static list in your Part 2 code
        sentMessages.add(m);
        // ensure the IDs/hashes lists contain entries (they were added during populate)
        if (!messageIDs.contains(m.messageID)) messageIDs.add(m.messageID);
        if (!messageHashes.contains(m.messageHash)) messageHashes.add(m.messageHash);
    }

    private void addMessageToStored(Message m) {
        // store for later
        storedMessages.add(m);
        if (!messageIDs.contains(m.messageID)) messageIDs.add(m.messageID);
        if (!messageHashes.contains(m.messageHash)) messageHashes.add(m.messageHash);
    }

    private void addMessageToDisregarded(Message m) {
        disregardedMessages.add(m);
        if (!messageIDs.contains(m.messageID)) messageIDs.add(m.messageID);
        if (!messageHashes.contains(m.messageHash)) messageHashes.add(m.messageHash);
    }

    // Getters for arrays (as required by Part 3)
    public List<Message> getSentMessages() { return Collections.unmodifiableList(sentMessages); }
    public List<Message> getDisregardedMessages() { return Collections.unmodifiableList(disregardedMessages); }
    public List<Message> getStoredMessages() { return Collections.unmodifiableList(storedMessages); }
    public List<String> getMessageHashes() { return Collections.unmodifiableList(messageHashes); }
    public List<String> getMessageIDs() { return Collections.unmodifiableList(messageIDs); }

    /**
     * Display the sender and recipient of all sent messages.
     * Uses the provided User as the sender.
     *
     * Returns a formatted multi-line string that lists, for each sent message:
     * Sender: <first last> - Recipient: <recipient>
     */
    public String displaySenderAndRecipient(User sender) {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Sender: ").append(sender.getFirstName()).append(" ").append(sender.getLastName());
            sb.append(" - Recipient: ").append(m.recipient).append("\n");
        }
        return sb.toString();
    }

    /**
     * Return the longest message text among all messages in the test data
     * (searches sent, stored and disregarded lists). This follows the assignment examples.
     */
    public String getLongestMessage() {
        List<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(storedMessages);
        all.addAll(disregardedMessages);

        if (all.isEmpty()) return "";

        Message longest = Collections.max(all, Comparator.comparingInt(m -> m.messageText == null ? 0 : m.messageText.length()));
        return longest.messageText;
    }

    /**
     * Search for a message by message ID across all arrays.
     * Returns the message text if found, null otherwise.
     */
    public String findMessageByID(String messageIDToFind) {
        // search sent
        for (Message m : sentMessages) {
            if (messageIDToFind.equals(m.messageID)) return m.messageText;
        }
        // search stored
        for (Message m : storedMessages) {
            if (messageIDToFind.equals(m.messageID)) return m.messageText;
        }
        // search disregarded
        for (Message m : disregardedMessages) {
            if (messageIDToFind.equals(m.messageID)) return m.messageText;
        }
        return null;
    }

    /**
     * Search for all messages sent or stored to a particular recipient.
     * Returns a list of Message objects matching the recipient across sent and stored arrays.
     */
    public List<Message> findMessagesByRecipient(String recipientToFind) {
        List<Message> results = new ArrayList<>();
        for (Message m : sentMessages) {
            if (m.recipient != null && m.recipient.equals(recipientToFind)) results.add(m);
        }
        for (Message m : storedMessages) {
            if (m.recipient != null && m.recipient.equals(recipientToFind)) results.add(m);
        }
        return results;
    }

    /**
     * Delete a message by message hash. Searches all arrays (sent, stored, disregarded).
     * If found, removes the message from its array and from messageHashes/messageIDs lists.
     * Returns the deleted message text, or null if not found.
     */
    public String deleteMessageByHash(String hash) {
        // check sent messages
        for (int i = 0; i < sentMessages.size(); i++) {
            Message m = sentMessages.get(i);
            if (hash.equals(m.messageHash)) {
                sentMessages.remove(i);
                // also remove from static Message.sentMessages list if present
                Message.sentMessages.remove(m);
                messageHashes.remove(m.messageHash);
                messageIDs.remove(m.messageID);
                return m.messageText;
            }
        }
        // check stored
        for (int i = 0; i < storedMessages.size(); i++) {
            Message m = storedMessages.get(i);
            if (hash.equals(m.messageHash)) {
                storedMessages.remove(i);
                messageHashes.remove(m.messageHash);
                messageIDs.remove(m.messageID);
                return m.messageText;
            }
        }
        // check disregarded
        for (int i = 0; i < disregardedMessages.size(); i++) {
            Message m = disregardedMessages.get(i);
            if (hash.equals(m.messageHash)) {
                disregardedMessages.remove(i);
                messageHashes.remove(m.messageHash);
                messageIDs.remove(m.messageID);
                return m.messageText;
            }
        }
        return null;
    }

    /**
     * Display a report that lists the full details of all sent messages.
     * Report includes: Message Hash, Recipient, Message (one message per block)
     */
    public String displayReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("Report - Sent Messages\n");
        sb.append("----------------------\n");
        for (Message m : sentMessages) {
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n");
            sb.append("\n");
        }
        return sb.toString();
    }
}
