import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

public class MessageTest {
    
    private Message message1;
    private Message message2;
    
    @Before
    public void setUp() {
        // Test Message 1: Valid message
        message1 = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight");
        
        // Test Message 2: Invalid recipient format
        message2 = new Message(2, "08575975889", "Hi Keegan, did you receive the payment?");
    }
    
    // Test 1: Message Length Validation
    @Test
    public void testMessageLengthValidation() {
        System.out.println("=== Test 1: Message Length Validation ===");
        
        // Test valid length (under 250 chars)
        String validMessage = "Short message";
        Message shortMessage = new Message(1, "+27123456789", validMessage);
        // Note: Your original Message class doesn't have checkMessageLength() method
        // We'll test this by checking if messageText is stored correctly
        assertEquals("Short message", shortMessage.messageText);
        System.out.println("Valid length test: Message stored correctly");
        
        // Test long message (your GUI handles length validation)
        String longMessage = "A".repeat(300);
        Message longMsg = new Message(2, "+27123456789", longMessage);
        assertEquals(300, longMsg.messageText.length());
        System.out.println("Long message test: Message stored with " + longMsg.messageText.length() + " characters");
    }
    
    // Test 2: Recipient Phone Format Validation - FIXED
    @Test
    public void testRecipientPhoneFormat() {
        System.out.println("\n=== Test 2: Recipient Phone Format ===");
        
        // Test valid recipient (starts with +) - returns 1 for success
        int result1 = message1.checkRecipientCell();
        assertEquals(1, result1); // Should return 1 for valid
        System.out.println("Valid recipient test: Returned " + result1 + " (1 = success)");
        
        // Test invalid recipient (doesn't start with +) - returns 0 for fail
        int result2 = message2.checkRecipientCell();
        assertEquals(0, result2); // Should return 0 for invalid
        System.out.println("Invalid recipient test: Returned " + result2 + " (0 = fail)");
        
        // Test edge cases
        Message edgeCase1 = new Message(3, "+271234567890", "Test"); // 13 chars
        Message edgeCase2 = new Message(4, "+27", "Test"); // Too short but starts with +
        Message edgeCase3 = new Message(5, "27718693002", "Test"); // No +
        
        assertEquals(1, edgeCase1.checkRecipientCell()); // Valid: starts with + and <= 15 chars
        assertEquals(1, edgeCase2.checkRecipientCell()); // Valid: starts with +
        assertEquals(0, edgeCase3.checkRecipientCell()); // Invalid: no +
    }
    
    // Test 3: Message Hash Generation
    @Test
    public void testMessageHashGeneration() {
        System.out.println("\n=== Test 3: Message Hash Generation ===");
        
        String hash = message1.messageHash;
        assertNotNull("Hash should not be null", hash);
        assertTrue("Hash should contain colons", hash.contains(":"));
        
        // Check format: FirstTwo:MessageNum:FIRSTWORDLASTWORD
        String[] parts = hash.split(":");
        assertEquals("Hash should have 3 parts", 3, parts.length);
        assertEquals("First part should be 2 characters", 2, parts[0].length());
        assertEquals("Second part should be message number", "1", parts[1]);
        
        // Test hash with different messages
        Message testMsg1 = new Message(5, "+27123456789", "Hello World");
        assertTrue(testMsg1.messageHash.contains("HELLO"));
        assertTrue(testMsg1.messageHash.contains("WORLD"));
        
        Message testMsg2 = new Message(6, "+27123456789", "Single");
        String hash2 = testMsg2.messageHash;
        String[] parts2 = hash2.split(":");
        assertEquals("SINGLESINGLE", parts2[2]); // Single word repeated
        
        System.out.println("Generated hash: " + hash);
        System.out.println("Hash format: FirstTwo:MessageNum:FIRSTWORDLASTWORD - ✓");
    }
    
    // Test 4: Message ID Creation
    @Test
    public void testMessageIDCreation() {
        System.out.println("\n=== Test 4: Message ID Creation ===");
        
        boolean isValidID1 = message1.checkMessageID();
        boolean isValidID2 = message2.checkMessageID();
        
        assertTrue("Message 1 ID should be valid", isValidID1);
        assertTrue("Message 2 ID should be valid", isValidID2);
        
        assertEquals("Message 1 ID should be 10 digits", 10, message1.messageID.length());
        assertEquals("Message 2 ID should be 10 digits", 10, message2.messageID.length());
        
        // Test that IDs are numeric
        assertTrue("Message 1 ID should be numeric", message1.messageID.matches("\\d+"));
        assertTrue("Message 2 ID should be numeric", message2.messageID.matches("\\d+"));
        
        // Test that IDs are different (random)
        assertNotEquals("Message IDs should be different", message1.messageID, message2.messageID);
        
        System.out.println("Message 1 ID: " + message1.messageID + " (length: " + message1.messageID.length() + ")");
        System.out.println("Message 2 ID: " + message2.messageID + " (length: " + message2.messageID.length() + ")");
        System.out.println("Both IDs are 10 digits and numeric: ✓");
    }
    
    // Test 5: Message Actions (Send, Discard, Store) - FIXED
    @Test
    public void testMessageActions() {
        System.out.println("\n=== Test 5: Message Actions ===");
        
        // Clear any previous messages
        Message.sentMessages.clear();
        
        // Test Send action
        String sendResult = message1.SentMessage(1);
        assertEquals("Message successfully sent.", sendResult);
        assertEquals("Should have 1 sent message", 1, Message.sentMessages.size());
        System.out.println("Send action: " + sendResult + " | Total sent: " + Message.returnTotalMessages());
        
        // Test Discard action
        String discardResult = message1.SentMessage(2);
        assertEquals("Press 0 to delete message.", discardResult);
        assertEquals("Should still have 1 sent message", 1, Message.sentMessages.size());
        System.out.println("Discard action: " + discardResult);
        
        // Test Store action
        String storeResult = message1.SentMessage(3);
        assertEquals("Message successfully stored.", storeResult);
        assertEquals("Should still have 1 sent message", 1, Message.sentMessages.size());
        System.out.println("Store action: " + storeResult);
        
        // Test invalid action
        String invalidResult = message1.SentMessage(99);
        assertEquals("Invalid option.", invalidResult);
        System.out.println("Invalid action: " + invalidResult);
        
        // Test multiple sends
        Message newMessage = new Message(10, "+27123456789", "Another message");
        newMessage.SentMessage(1);
        assertEquals("Should have 2 sent messages", 2, Message.sentMessages.size());
        System.out.println("Multiple sends test: Total messages = " + Message.returnTotalMessages());
    }
    
    // Additional Test: Print Messages functionality
    @Test
    public void testPrintMessages() {
        System.out.println("\n=== Test 6: Print Messages ===");
        
        // Clear previous messages
        Message.sentMessages.clear();
        
        // Add test messages
        Message.sentMessages.add(message1);
        Message.sentMessages.add(message2);
        
        String printed = Message.printMessages();
        assertNotNull("Printed messages should not be null", printed);
        assertTrue("Should contain MessageID", printed.contains("MessageID"));
        assertTrue("Should contain Message Hash", printed.contains("Message Hash"));
        assertTrue("Should contain Recipient", printed.contains("Recipient"));
        assertTrue("Should contain Message", printed.contains("Message"));
        
        System.out.println("Print Messages output format is correct: ✓");
    }
    
    // Test static message counter
    @Test
    public void testStaticMessageCounter() {
        System.out.println("\n=== Test 7: Static Message Counter ===");
        
        // Clear previous messages
        Message.sentMessages.clear();
        
        assertEquals("Initial count should be 0", 0, Message.returnTotalMessages());
        
        // Add messages directly to static list
        Message.sentMessages.add(message1);
        assertEquals("Count should be 1 after adding", 1, Message.returnTotalMessages());
        
        Message.sentMessages.add(message2);
        assertEquals("Count should be 2 after adding second", 2, Message.returnTotalMessages());
        
        System.out.println("Static counter test: " + Message.returnTotalMessages() + " messages total");
    }
}