/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * JUnit 4 tests for MessageManager (Part 3).
 *
 * These tests use the assignment test data (messages 1-5) and assert the expected behaviour described
 * in the brief:
 * - Sent messages array correctly populated (messages flagged "Sent")
 * - Display the longest message from test data
 * - Search for a message by message ID (message 4 "0838884567")
 * - Search all messages regarding a particular recipient (+27838884567)
 * - Delete a message using its message hash (Test Message 2)
 * - Display report contains required fields
 *
 * NOTE: JUnit 4 is required on the classpath to run these tests.
 */
public class MessageManagerTest {

    private MessageManager manager;

    @Before
    public void setUp() {
        manager = new MessageManager();
        manager.populateTestData();
    }

    @Test
    public void testSentMessagesArrayPopulated() {
        List<Message> sent = manager.getSentMessages();
        // From the test data Message 1 and Message 4 are flagged Sent
        assertEquals(2, sent.size());
        boolean hasMsg1 = sent.stream().anyMatch(m -> m.messageText != null && m.messageText.contains("Did you get the cake"));
        boolean hasMsg4 = sent.stream().anyMatch(m -> m.messageText != null && m.messageText.contains("It is dinner time"));
        assertTrue("Sent messages should contain message 1 text", hasMsg1);
        assertTrue("Sent messages should contain message 4 text", hasMsg4);
    }

    @Test
    public void testDisplayLongestMessage() {
        // The expected longest message as per the brief (messages 1-4)
        String expected = "Where are you? You are late! I have asked you to be on time.";
        String actual = manager.getLongestMessage();
        assertEquals(expected, actual);
    }

    @Test
    public void testSearchByMessageID() {
        // Test Data: search for messageID "0838884567" (Message 4)
        String found = manager.findMessageByID("0838884567");
        assertNotNull("Message with ID 0838884567 should be found", found);
        assertEquals("It is dinner time !", found);
    }

    @Test
    public void testSearchByRecipient() {
        // Test Data: recipient +27838884567 should have two messages (message 2 stored, message 5 stored)
        List<Message> results = manager.findMessagesByRecipient("+27838884567");
        assertFalse("Should find messages for recipient +27838884567", results.isEmpty());
        boolean foundWhereAreYou = results.stream().anyMatch(m -> m.messageText != null && m.messageText.contains("Where are you?"));
        boolean foundOkLeaving = results.stream().anyMatch(m -> m.messageText != null && m.messageText.contains("Ok, I am leaving without you."));
        assertTrue(foundWhereAreYou);
        assertTrue(foundOkLeaving);
    }

    @Test
    public void testDeleteByHash() {
        // Delete Test Message 2 by its hash (find message 2 in stored messages)
        Message toDelete = manager.getStoredMessages().stream().filter(m -> m.messageNum == 2).findFirst().orElse(null);
        assertNotNull("Test message 2 should exist in stored messages", toDelete);
        String hash = toDelete.messageHash;
        String deletedText = manager.deleteMessageByHash(hash);
        assertEquals("Deleted message text should match", toDelete.messageText, deletedText);

        // confirm message no longer present in stored messages
        boolean stillThere = manager.getStoredMessages().stream().anyMatch(m -> hash.equals(m.messageHash));
        assertFalse("Message should be removed from stored messages", stillThere);
    }

    @Test
    public void testDisplayReport() {
        String report = manager.displayReport();
        assertTrue("Report should contain Message Hash header", report.contains("Message Hash"));
        assertTrue("Report should contain Recipient header", report.contains("Recipient"));
        assertTrue("Report should contain Message header", report.contains("Message"));
    }
}